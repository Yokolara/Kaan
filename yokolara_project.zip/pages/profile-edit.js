export default function ProfileEdit() {
  return (
    <div style={{ padding: '2rem' }}>
      <h2>Profilini Düzenle</h2>
      <form>
        <div>
          <label>Ad Soyad:</label>
          <input type="text" placeholder="Adınızı girin" />
        </div>
        <div>
          <label>Profil Fotoğrafı:</label>
          <input type="file" />
        </div>
        <button type="submit">Kaydet</button>
      </form>
    </div>
  );
}
