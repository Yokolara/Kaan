export default function Home() {
  return (
    <div style={{ padding: '2rem', textAlign: 'center' }}>
      <h1>Yokolara'ya Hoş Geldin 🎉</h1>
      <a href="/profile-edit">Profilini Düzenle</a>
    </div>
  );
}
